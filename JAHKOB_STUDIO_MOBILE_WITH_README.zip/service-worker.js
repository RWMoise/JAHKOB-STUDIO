
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open('jahkob-cache').then(function(cache) {
      return cache.addAll([
        './',
        './index.html',
        './manifest.json',
        './icon-192.png',
        './icon-512.png',
        './sounds/piano_C.mp3',
        './sounds/piano_D.mp3',
        './sounds/piano_E.mp3',
        './sounds/piano_F.mp3',
        './sounds/piano_G.mp3',
        './sounds/piano_A.mp3',
        './sounds/piano_B.mp3',
        './sounds/guitar_C.mp3',
        './sounds/guitar_D.mp3',
        './sounds/guitar_E.mp3',
        './sounds/guitar_F.mp3',
        './sounds/guitar_G.mp3',
        './sounds/guitar_A.mp3',
        './sounds/guitar_B.mp3'
      ]);
    })
  );
});

self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(response) {
      return response || fetch(event.request);
    })
  );
});
