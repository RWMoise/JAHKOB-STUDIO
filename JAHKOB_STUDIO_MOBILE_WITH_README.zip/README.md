# 🎙️ JAHKOB STUDIO – App Mobile Audio

JAHKOB STUDIO se yon Progressive Web App (PWA) ki pèmèt ou:
- 🎤 Anrejistre vwa w ak efè (Echo, Reverb, AutoGain)
- 🎹 Jwe not mizikal sou klavye vityèl (Piano/Gita)
- 📤 Telechaje oswa voye fichye anrejistre
- 📱 Enstale app la sou telefòn oswa tablèt
- 📴 Itilize offline

## ✅ Kijan pou itilize
1. Louvri `index.html` ak yon navigatè modèn (Chrome, Safari, Edge)
2. Peze **Kòmanse** pou anrejistre, **Sispann**, epi **Telechaje**
3. Jwe not ak klavye a
4. Chwazi efè ou vle anvan w kòmanse anrejistre

## 🛠 Enstalasyon
- 📁 Mete tout fichye yo sou GitHub Pages, Vercel, oswa Netlify
- App lan mache offline gras ak `service-worker.js`
- App lan enstalab sou mobil via `manifest.json`

## 📦 Dosye kle
- `index.html` – entèfas app la
- `manifest.json` – meta done pou mobil
- `service-worker.js` – cache offline
- `sounds/` – son not yo (piano & gita)
- `icon-192.png` / `icon-512.png` – ikòn app la

## 📧 Aksè fichye
Voye fichye sèlman si imel ou otorize (`mwen@jahkob.com`, `admin@jahkob.com`)

## 🔒 Offline & Enstalasyon
- App lan mache **san koneksyon**
- Peze **"Ajouter à l'écran d'accueil"** pou enstale app sou telefòn

---

© 2025 – JAHKOB PRODUCTION 🎶
